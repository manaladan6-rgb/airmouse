"""AirMouse — Physics-driven webcam finger mouse. v5.0 VOICE + KALMAN edition."""
__version__ = "11.5.0"
